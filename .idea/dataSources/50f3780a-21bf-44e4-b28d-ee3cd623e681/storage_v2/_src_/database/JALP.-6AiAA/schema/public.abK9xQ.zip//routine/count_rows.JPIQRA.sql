create function count_rows(schema text, tablename text) returns integer
    language plpgsql
as
$$
declare
  result integer;
  query varchar;
begin
  query := 'SELECT count(1) FROM ' || schema || '.' || tablename;
  execute query into result;
  return result;
end;
$$;

alter function count_rows(text, text) owner to postgres;

